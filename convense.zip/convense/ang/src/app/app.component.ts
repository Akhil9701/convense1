// app.component.ts

import { Component, DoCheck } from '@angular/core';

import { Observable, of } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements DoCheck {

  constructor(private router:Router){}
  localval:Observable<any>

  logOutClick(){
    localStorage.removeItem("uid");
    this.router.navigate(['login']);
  }
  CheckLocalStore(): Observable<any> {
    return of(localStorage.getItem("uid"));

}
ngDoCheck(){
  this.CheckLocalStore().subscribe((data) => { this.localval = data })
}
}