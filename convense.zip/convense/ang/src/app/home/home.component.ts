import { Component, OnInit } from '@angular/core';
import { CookieService } from 'angular2-cookie/services/cookies.service';
import { LocalStorageService, SessionStorageService } from 'ngx-webstorage';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private cookieservice: CookieService, private localStorage: LocalStorageService, private sessionStorage: SessionStorageService) { }

  setCookies() {
    this.cookieservice.put('test', 'testing cookie')
  }
  getCookies() {
    alert(this.cookieservice.get("test"));
  }
  delCookies() {
    this.cookieservice.remove("test");
  }

  setLocalStorage() {
    this.localStorage.store('username', "akhil")
  }
  getLocalStorage() {
    alert(this.localStorage.retrieve('username'))
  }
  delLocalStorage() {
    this.localStorage.clear('boundValue')
  }

  setSessionStorage() {
    this.sessionStorage.store("logged-in", "user")
  }
  getSessionStorage() {
    alert(this.sessionStorage.retrieve("logged-in"))
  }


  delSessionStorage() {
    this.sessionStorage.clear("logged-in")
  }
  ngOnInit() {
  }

}
