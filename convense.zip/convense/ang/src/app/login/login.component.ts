import { Component, OnInit } from '@angular/core';
import { Register } from '../models/register';
import { Router } from '@angular/router';
import { ExampleService } from '../services/example.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
login:Register


  constructor(private router:Router,private exampleservice:ExampleService) 
  {
    this.login=new Register();
   }

   btnLoginClick(u,p) {

    this.exampleservice.CheckLogin(u, p).subscribe((data) => {
      
        if (data.length > 0) {
          alert('Login succesfull.....')
            localStorage.setItem("uid", u)
            this.router.navigate(['home'])
        }
        else {
            alert('Invalid User...You need to signup')
        }
    })
}
  ngOnInit() {
  }

}
