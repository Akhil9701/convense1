export class Register{
    firstname:string;
    lastname:string;
    email:string;
    password:string;
    mobile:number;
}