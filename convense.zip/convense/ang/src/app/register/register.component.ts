import { Component, OnInit } from '@angular/core';
import { Register } from '../models/register';
import { Router } from '@angular/router';
import { ExampleService } from '../services/example.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
reg:Register
  constructor(private rt:Router,private exampleservice:ExampleService   ) {
    this.reg=new Register();
   }
   btnSubmitClick(regForm){
     let frmValid:boolean
     frmValid=regForm.valid
     if(frmValid==true)
     alert('Registered successfully')
     else
     alert('Invalid details')
   }

   funsubmit(regForm){
     if(regForm.valid){
       this.exampleservice.register(this.reg).subscribe((data)=>{
         this.rt.navigate(['login'])
       })
     }
   }

  ngOnInit() {
  }

}
