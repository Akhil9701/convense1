import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Register } from '../models/register';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ExampleService {


  apiUrl: string = "http://localhost:4600/register";
  constructor(private http:HttpClient) { }

  register(regObj:Register):Observable<any>{
    const headers={
      headers:new HttpHeaders({'content-type':'application/json'})
    }
    return this.http.post(this.apiUrl,JSON.stringify(regObj),headers)
  }

  CheckLogin(ui: string, p: string): Observable<any> {

    return this.http.get('http://localhost:4600/register/' + ui + '/' + p, { responseType: 'json' });
  }
}
