
var express=require('express')
var bodyparser = require('body-parser')
var express = require('express')
var promise = require('bluebird')
var app = express();
var options = { promiseLib: promise }



var pgp = require('pg-promise')(options)
var cs = 'postgres://postgres:root@localhost:5432/convense'

var db = pgp(cs)


app.use(bodyparser.urlencoded({ extended: true }));
app.use(bodyparser.json());

app.set('port',process.env.PORT || 4600)

app.use(function (req, res, next) {

    res.setHeader('Access-Control-Allow-Origin', '*');


    res.setHeader('Access-Control-Allow-Methods', '*');


    res.setHeader('Access-Control-Allow-Headers', '*');


    res.setHeader('Access-Control-Allow-Credentials', true);


    next();
});

app.get('/', (req, res) => {
    res.send('Database coinnectivity Ex.....')
})

app.get('/register', (req, res, next) => {
    db.any('select * from  register').then(
        (data) => {
            res.send(data)
        })
})


app.post('/register',(req,res,next)=>{
    console.log(req.body.firstname)
    var i= parseInt(req.body.uid)
    var n = req.body.firstname
    var l = req.body.lastname
    var e = req.body.email
    var pw = req.body.password
    var m = req.body.mobile
    db.any('insert into register values($1,$2,$3,$4,$5,$6)',[i,n,l,e,pw,m]).then((data)=>{
        res.send({ 'message': 'Registered successfully'})
    })
})

app.get('/register/:uid/:password', (req, res, next) => {
    var ui = req.params.uid
    var p = req.params.password
    console.log(ui + " " + p);
    db.any('select * from register where uid=$1 and password=$2', [ui, p])
        .then((data) => {
            res.send(data)
        })

})


app.listen(app.get('port'), (err) => {
    if (err)
        console.log('server not started')
    else
        console.log('server Started at  : http://localhost:4600')
})